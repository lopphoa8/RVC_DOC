////////////////////////////////////////////////
////s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~s////
////s           www.testbench.in           s////
////s                                      s////
////s              UVM Tutorial            s////
////s                                      s////
////s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~s////
////////////////////////////////////////////////

For any Questions 

Contact  gopi@testbench.in


~~~~~~~~~~~~~~~~~~~~~~~~
  Make file options
~~~~~~~~~~~~~~~~~~~~~~~~
For VCS : make vcs
For Questa : make questa
To Clean : make clean
~~~~~~~~~~~~~~~~~~~~~~~~
 
