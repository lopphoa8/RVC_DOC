script type
ftplugin
 
description
upgrade form   "http://www.vim.org/scripts/script.php?script_id=2372

Support Automatic functions like Emacs for Verilog HDL

Date: 2017-09-18 upload.

Description:
    For write verilog code more automatic.
    Like Emacs for Verilog HDL.

Use it in gvim.

File path:
    vim/.vim/plugin/automatic.vim   -- vim script
    vim/.vim/after                  -- icon images

Function:
use in gvim normal mode:

AutoTemplate    -- Add simple format code in *.v.
                   include: AutoHeader ...
                   setenv in your .cshrc for AutoHeader:
                       setenv COMPANY "your company name"
                       setenv USER_DIT "your alias name"
              
<F2>            -- Comment/un-Comment single line with simple info.  -- with //
<F3>            -- Comment/un-Comment multi  line,  -- with /*  ... */
                   use <Ctrl-V> select multi lines, then <F3>
<F4>            -- Add a comment at end of current line
              



<Shift-F1>      -- AutoArg, Auto fill module module port arg(same as Emacs).
                   below line /*autoarg*/
<Shift-F2>      -- Auto Define Signals,
                   below line /*autodef*/
<Shift-F3>      -- Auto Instance.   -- line with /*autoinst*/
                   goto module instantiation line, the <Shift-F3>.
                   It is more useful.
                   -- sometimes with bug, please re-open .v file.

:RtlTree        -- Like Verdi.
                   Left-Click:  go to specified sub-module instance line.
                   Left-DoubleClick / Enter Key:  go to specified module define line.
                   <Crtl-Alt-A>: go to hierarchical module instantiation line.
                   <Crtl-Alt-N>: go to hierarchical module define line.
                   -- Verdi is more powerful, so ...


Icon shortcut in gvim GUI upper-rigth:
PN: always @(posedge clk or negedge rst_n)
* : always @(*)
NN: always @(negedge clk or negedge rst_n)
ShowCall: goto current sub-modue instance line in parent module source file.
             -- only use in RtlTree have open.
ShowDef : goto current sub-modue source file. -- only use in RtlTree have open.


Note:
Some function base on tags.
You may need update tags with ctags_gen script with all your *.v file.
ctags_gen *.v    or
ctags_gen -L verilog_file.lst

You can modify this automatic.vim for your want.




////////////////////////////////////////////////////////////////////////////////////////////////
//         version info before 2014.
////////////////////////////////////////////////////////////////////////////////////////////////

=========================================================
=  Install
=========================================================

1. vim version need >= 7.0
2. copy automatic.vim to your home directory .vim/plugin/
3. decompress Draw_pixmaps.rar, copy *.xpm file to .vim/after,
   if directory no exist, create it.
4. modify your vim config file .vimrc:
  
   set fileformat=unix
   syntax on

   set expandtab        " use <space> char replace <tab> char

   set shiftwidth=4
   set tabstop=4
   set ruler
  
   set smartindent
   set incsearch
   set hlsearch

   map <F4> :RtlTree<CR>
   map <F5> <C-w><C-w>

   " save cursor position at exit edit file
   autocmd BufReadPost *
       \ if (line("'\"") > 0 && line("'\"") <= line("$") |
       \    exe "normal g`\"" |
       \ endif


=========================================================
=  Usage
=========================================================

== Automatic for Verilog

1. Auto Argument,         :call AutoArg()   or shortcut key <Shift>+<F1>
2. Auto Definition,       :call AutoDef()   or shortcut key <Shift>+<F2>
3. Auto Instance,         :call AutoInst(0) or shortcut key <Shift>+<F3>  "key words /*autoinst*/
4. Auto Comment,
     single line comment, :call AutoComment()  or shortcut key <F2>
     multi line comment,  :call AutoComment2() or shortcut key <F3>
5. "Always @" block quick input template, leftclick icon "AL**"
6. abbrev "<=" to "<= #1" in insert mode

== Draw wave

1. leftclick icon "CLK" to create a clock signal wave
2. leftclick icon "SIG" to create a one-bit signal wave
3. leftclick icon "BUS" to create a bus signal wave
4. leftclick icon "SEP" to create a blank line
5. leftclick icon "NEG" to add a flag char 'neg' to end of one sig
6. to draw wave use shortcut key <F8>

note: goto bottom line of sig line(total 3 lines) to create a new sig/blank line

== RtlTree

1. Only use in gvim
2. use script ctags_gen to create file tags, rtltree work need file tags
3. Use like Verdi


=========================================================
=  Limit
=========================================================

1. One design unit per file

        A file must not contain more than one design unit. Everything contained in a design
     unit must be completely contained in a single module/endmodule construct.

2. File naming conventions

    The file name must be composed in the following way:
    <design unit name>.v

    where:
    <design unit name> is the name of the design unit (i.e., module name).

    example: spooler.v Synthesizable Verilog code for module spooler

 
install details